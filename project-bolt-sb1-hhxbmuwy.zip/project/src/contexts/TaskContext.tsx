import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Task, Category, CreateTaskData } from '../types';
import { aiService } from '../services/aiService';
import { storageService } from '../services/storageService';

interface TaskContextType {
  tasks: Task[];
  categories: Category[];
  addTask: (taskData: CreateTaskData) => Promise<void>;
  updateTask: (id: string, updates: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  addCategory: (name: string, color: string) => void;
  deleteCategory: (id: string) => void;
  toggleTask: (id: string) => void;
  summarizeTask: (id: string) => Promise<string>;
  prioritizeTasks: () => Promise<{ task: Task; reasoning: string }[]>;
}

const TaskContext = createContext<TaskContextType | undefined>(undefined);

export const useTask = () => {
  const context = useContext(TaskContext);
  if (!context) {
    throw new Error('useTask must be used within a TaskProvider');
  }
  return context;
};

export const TaskProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [categories, setCategories] = useState<Category[]>([
    { id: '1', name: 'Work', color: '#2563eb' },
    { id: '2', name: 'Personal', color: '#7c3aed' },
    { id: '3', name: 'Health', color: '#10b981' },
    { id: '4', name: 'Learning', color: '#f59e0b' },
  ]);

  useEffect(() => {
    const storedTasks = storageService.getTasks();
    const storedCategories = storageService.getCategories();
    
    if (storedTasks.length > 0) setTasks(storedTasks);
    if (storedCategories.length > 0) setCategories(storedCategories);
  }, []);

  useEffect(() => {
    storageService.saveTasks(tasks);
  }, [tasks]);

  useEffect(() => {
    storageService.saveCategories(categories);
  }, [categories]);

  const addTask = async (taskData: CreateTaskData) => {
    let aiSuggestions = { category: '', priority: 'medium' as const };
    
    try {
      aiSuggestions = await aiService.suggestCategoryAndPriority(taskData.title, categories);
    } catch (error) {
      console.error('AI suggestion failed:', error);
    }

    const newTask: Task = {
      id: Date.now().toString(),
      title: taskData.title,
      description: taskData.description || '',
      category: taskData.category || aiSuggestions.category,
      priority: taskData.priority || aiSuggestions.priority,
      deadline: taskData.deadline,
      recurring: taskData.recurring || 'none',
      completed: false,
      createdAt: new Date().toISOString(),
    };

    setTasks(prev => [...prev, newTask]);
  };

  const updateTask = (id: string, updates: Partial<Task>) => {
    setTasks(prev => prev.map(task => 
      task.id === id ? { ...task, ...updates } : task
    ));
  };

  const deleteTask = (id: string) => {
    setTasks(prev => prev.filter(task => task.id !== id));
  };

  const toggleTask = (id: string) => {
    setTasks(prev => prev.map(task => 
      task.id === id ? { ...task, completed: !task.completed } : task
    ));
  };

  const addCategory = (name: string, color: string) => {
    const newCategory: Category = {
      id: Date.now().toString(),
      name,
      color,
    };
    setCategories(prev => [...prev, newCategory]);
  };

  const deleteCategory = (id: string) => {
    setCategories(prev => prev.filter(cat => cat.id !== id));
    // Update tasks that used this category
    setTasks(prev => prev.map(task => 
      task.category === categories.find(cat => cat.id === id)?.name 
        ? { ...task, category: '' } 
        : task
    ));
  };

  const summarizeTask = async (id: string): Promise<string> => {
    const task = tasks.find(t => t.id === id);
    if (!task) return '';
    
    try {
      return await aiService.summarizeTask(task);
    } catch (error) {
      console.error('Task summarization failed:', error);
      return 'Unable to generate summary at this time.';
    }
  };

  const prioritizeTasks = async (): Promise<{ task: Task; reasoning: string }[]> => {
    try {
      return await aiService.prioritizeTasks(tasks);
    } catch (error) {
      console.error('Task prioritization failed:', error);
      return tasks.map(task => ({
        task,
        reasoning: 'Unable to generate AI reasoning at this time.'
      }));
    }
  };

  return (
    <TaskContext.Provider value={{
      tasks,
      categories,
      addTask,
      updateTask,
      deleteTask,
      addCategory,
      deleteCategory,
      toggleTask,
      summarizeTask,
      prioritizeTasks,
    }}>
      {children}
    </TaskContext.Provider>
  );
};