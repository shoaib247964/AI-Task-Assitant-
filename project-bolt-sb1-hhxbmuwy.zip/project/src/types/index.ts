export interface Task {
  id: string;
  title: string;
  description: string;
  category: string;
  priority: 'low' | 'medium' | 'high';
  deadline?: string;
  recurring: 'none' | 'daily' | 'weekly' | 'monthly';
  completed: boolean;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  color: string;
}

export interface CreateTaskData {
  title: string;
  description?: string;
  category?: string;
  priority?: 'low' | 'medium' | 'high';
  deadline?: string;
  recurring?: 'none' | 'daily' | 'weekly' | 'monthly';
}