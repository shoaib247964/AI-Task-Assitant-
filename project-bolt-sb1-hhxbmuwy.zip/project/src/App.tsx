import React, { useState, useEffect } from 'react';
import { TaskProvider } from './contexts/TaskContext';
import { Header } from './components/Header';
import { TaskList } from './components/TaskList';
import { AddTaskForm } from './components/AddTaskForm';
import { CategoryManager } from './components/CategoryManager';
import { AIAssistant } from './components/AIAssistant';
import { TaskPrioritizer } from './components/TaskPrioritizer';
import { NotificationManager } from './components/NotificationManager';

function App() {
  const [activeView, setActiveView] = useState<'tasks' | 'categories' | 'assistant' | 'prioritizer'>('tasks');
  const [showAddTask, setShowAddTask] = useState(false);

  useEffect(() => {
    // Request notification permission
    if ('Notification' in window) {
      Notification.requestPermission();
    }
  }, []);

  return (
    <TaskProvider>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
        <Header 
          activeView={activeView}
          setActiveView={setActiveView}
          onAddTask={() => setShowAddTask(true)}
        />
        
        <main className="max-w-6xl mx-auto px-6 py-8">
          {activeView === 'tasks' && (
            <div className="space-y-8">
              <TaskList />
            </div>
          )}
          
          {activeView === 'categories' && <CategoryManager />}
          {activeView === 'assistant' && <AIAssistant />}
          {activeView === 'prioritizer' && <TaskPrioritizer />}
        </main>

        {showAddTask && (
          <AddTaskForm onClose={() => setShowAddTask(false)} />
        )}

        <NotificationManager />
      </div>
    </TaskProvider>
  );
}

export default App;