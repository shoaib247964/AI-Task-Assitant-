import { Task, Category } from '../types';

const OPENAI_API_KEY = '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';

class AIService {
  private async callOpenAI(messages: any[], maxTokens: number = 200): Promise<string> {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages,
        max_tokens: maxTokens,
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status}`);
    }

    const data = await response.json();
    return data.choices[0].message.content.trim();
  }

  async suggestCategoryAndPriority(taskTitle: string, categories: Category[]): Promise<{
    category: string;
    priority: 'low' | 'medium' | 'high';
  }> {
    const categoryNames = categories.map(cat => cat.name);
    
    const messages = [
      {
        role: 'system',
        content: `You are a task categorization assistant. Given a task title, suggest the most appropriate category from the available options and a priority level (low, medium, high).

Available categories: ${categoryNames.join(', ')}

Respond in this exact format:
Category: [category name]
Priority: [priority level]

If no category fits perfectly, suggest the closest match or leave blank.`,
      },
      {
        role: 'user',
        content: `Task: "${taskTitle}"`,
      },
    ];

    try {
      const response = await this.callOpenAI(messages);
      
      const categoryMatch = response.match(/Category:\s*(.+)/i);
      const priorityMatch = response.match(/Priority:\s*(low|medium|high)/i);
      
      const suggestedCategory = categoryMatch ? categoryMatch[1].trim() : '';
      const suggestedPriority = priorityMatch ? priorityMatch[1].toLowerCase() as 'low' | 'medium' | 'high' : 'medium';
      
      // Validate category exists in available categories
      const validCategory = categoryNames.find(cat => 
        cat.toLowerCase() === suggestedCategory.toLowerCase()
      ) || '';
      
      return {
        category: validCategory,
        priority: suggestedPriority,
      };
    } catch (error) {
      console.error('AI suggestion error:', error);
      return { category: '', priority: 'medium' };
    }
  }

  async summarizeTask(task: Task): Promise<string> {
    const messages = [
      {
        role: 'system',
        content: `You are a task analysis assistant. Given a task, provide a concise summary and suggest 2-3 subtasks that would help complete it. Keep your response under 150 words.

Format your response as:
Summary: [brief summary]
Subtasks:
- [subtask 1]
- [subtask 2]
- [subtask 3]`,
      },
      {
        role: 'user',
        content: `Task: "${task.title}"
Description: "${task.description || 'No description provided'}"
Category: ${task.category}
Priority: ${task.priority}`,
      },
    ];

    return await this.callOpenAI(messages, 300);
  }

  async prioritizeTasks(tasks: Task[]): Promise<{ task: Task; reasoning: string }[]> {
    if (tasks.length === 0) return [];

    const incompleteTasks = tasks.filter(task => !task.completed);
    
    const messages = [
      {
        role: 'system',
        content: `You are a task prioritization assistant. Given a list of tasks, rank them in order of importance and urgency. For each task, provide a brief reasoning (1-2 sentences) explaining why it's positioned where it is.

Consider factors like:
- Deadlines
- Priority level
- Category importance
- Dependencies
- Impact

Format your response as:
1. [Task Title] - [Brief reasoning]
2. [Task Title] - [Brief reasoning]
...`,
      },
      {
        role: 'user',
        content: `Tasks to prioritize:
${incompleteTasks.map((task, idx) => 
  `${idx + 1}. "${task.title}" (Priority: ${task.priority}, Category: ${task.category}${task.deadline ? `, Deadline: ${task.deadline}` : ''})`
).join('\n')}`,
      },
    ];

    try {
      const response = await this.callOpenAI(messages, 500);
      
      // Parse the response and match with tasks
      const lines = response.split('\n').filter(line => line.trim());
      const prioritizedTasks: { task: Task; reasoning: string }[] = [];
      
      for (const line of lines) {
        const match = line.match(/^\d+\.\s*"([^"]+)"\s*-\s*(.+)$/);
        if (match) {
          const taskTitle = match[1];
          const reasoning = match[2];
          
          const task = incompleteTasks.find(t => t.title === taskTitle);
          if (task) {
            prioritizedTasks.push({ task, reasoning });
          }
        }
      }
      
      // Add any remaining tasks that weren't matched
      for (const task of incompleteTasks) {
        if (!prioritizedTasks.find(pt => pt.task.id === task.id)) {
          prioritizedTasks.push({
            task,
            reasoning: 'Standard priority based on current settings.'
          });
        }
      }
      
      return prioritizedTasks;
    } catch (error) {
      console.error('Task prioritization error:', error);
      return incompleteTasks.map(task => ({
        task,
        reasoning: 'Unable to generate AI reasoning at this time.'
      }));
    }
  }

  async askAssistant(question: string, tasks: Task[]): Promise<string> {
    const messages = [
      {
        role: 'system',
        content: `You are a helpful AI assistant that has access to the user's current task list. Use this context to provide relevant and personalized advice about task management, productivity, and answering questions related to their tasks.

Current tasks:
${tasks.map(task => 
  `- ${task.title} (${task.completed ? 'Completed' : 'Incomplete'}, Priority: ${task.priority}, Category: ${task.category}${task.deadline ? `, Deadline: ${task.deadline}` : ''})`
).join('\n')}

Provide helpful, actionable advice. Keep responses concise but informative.`,
      },
      {
        role: 'user',
        content: question,
      },
    ];

    return await this.callOpenAI(messages, 400);
  }
}

export const aiService = new AIService();