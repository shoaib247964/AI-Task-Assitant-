import { Task, Category } from '../types';

class StorageService {
  private readonly TASKS_KEY = 'ai-tasks';
  private readonly CATEGORIES_KEY = 'ai-categories';

  getTasks(): Task[] {
    try {
      const stored = localStorage.getItem(this.TASKS_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Error loading tasks:', error);
      return [];
    }
  }

  saveTasks(tasks: Task[]): void {
    try {
      localStorage.setItem(this.TASKS_KEY, JSON.stringify(tasks));
    } catch (error) {
      console.error('Error saving tasks:', error);
    }
  }

  getCategories(): Category[] {
    try {
      const stored = localStorage.getItem(this.CATEGORIES_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Error loading categories:', error);
      return [];
    }
  }

  saveCategories(categories: Category[]): void {
    try {
      localStorage.setItem(this.CATEGORIES_KEY, JSON.stringify(categories));
    } catch (error) {
      console.error('Error saving categories:', error);
    }
  }
}

export const storageService = new StorageService();