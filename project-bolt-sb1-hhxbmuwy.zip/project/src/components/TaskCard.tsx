import React, { useState } from 'react';
import { Calendar, Clock, CheckCircle, Circle, Edit3, Trash2, FileText, RotateCcw } from 'lucide-react';
import { useTask } from '../contexts/TaskContext';
import { Task } from '../types';

interface TaskCardProps {
  task: Task;
  onEdit: () => void;
}

export const TaskCard: React.FC<TaskCardProps> = ({ task, onEdit }) => {
  const { toggleTask, deleteTask, summarizeTask, categories } = useTask();
  const [isLoading, setIsLoading] = useState(false);
  const [summary, setSummary] = useState<string>('');
  const [showSummary, setShowSummary] = useState(false);

  const category = categories.find(cat => cat.name === task.category);
  
  const priorityColors = {
    low: 'bg-green-100 text-green-800',
    medium: 'bg-yellow-100 text-yellow-800',
    high: 'bg-red-100 text-red-800',
  };

  const recurringLabels = {
    none: '',
    daily: 'Daily',
    weekly: 'Weekly',
    monthly: 'Monthly',
  };

  const handleSummarize = async () => {
    setIsLoading(true);
    try {
      const result = await summarizeTask(task.id);
      setSummary(result);
      setShowSummary(true);
    } catch (error) {
      console.error('Summarization failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  const isOverdue = task.deadline && new Date(task.deadline) < new Date() && !task.completed;

  return (
    <div className={`bg-white rounded-xl shadow-sm border-2 transition-all duration-200 hover:shadow-md ${
      task.completed ? 'border-green-200 bg-green-50' : 'border-gray-200 hover:border-blue-200'
    }`}>
      <div className="p-6">
        <div className="flex items-start justify-between">
          <div className="flex items-start space-x-3 flex-1">
            <button
              onClick={() => toggleTask(task.id)}
              className={`mt-1 transition-colors duration-200 ${
                task.completed ? 'text-green-600' : 'text-gray-400 hover:text-green-600'
              }`}
            >
              {task.completed ? (
                <CheckCircle className="w-5 h-5" />
              ) : (
                <Circle className="w-5 h-5" />
              )}
            </button>

            <div className="flex-1 min-w-0">
              <div className="flex items-center space-x-2 mb-2">
                <h3 className={`font-semibold ${
                  task.completed ? 'text-green-800 line-through' : 'text-gray-900'
                }`}>
                  {task.title}
                </h3>
                
                {category && (
                  <span
                    className="px-2 py-1 text-xs font-medium rounded-full text-white"
                    style={{ backgroundColor: category.color }}
                  >
                    {category.name}
                  </span>
                )}
                
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${priorityColors[task.priority]}`}>
                  {task.priority}
                </span>
                
                {task.recurring !== 'none' && (
                  <span className="px-2 py-1 text-xs font-medium rounded-full bg-purple-100 text-purple-800 flex items-center space-x-1">
                    <RotateCcw className="w-3 h-3" />
                    <span>{recurringLabels[task.recurring]}</span>
                  </span>
                )}
              </div>

              {task.description && (
                <p className={`text-sm mb-2 ${
                  task.completed ? 'text-green-600' : 'text-gray-600'
                }`}>
                  {task.description}
                </p>
              )}

              <div className="flex items-center space-x-4 text-sm text-gray-500">
                <div className="flex items-center space-x-1">
                  <Clock className="w-4 h-4" />
                  <span>{formatDate(task.createdAt)}</span>
                </div>
                
                {task.deadline && (
                  <div className={`flex items-center space-x-1 ${
                    isOverdue ? 'text-red-600' : 'text-gray-500'
                  }`}>
                    <Calendar className="w-4 h-4" />
                    <span>{formatDate(task.deadline)}</span>
                    {isOverdue && <span className="font-medium">(Overdue)</span>}
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleSummarize}
              disabled={isLoading}
              className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors duration-200 disabled:opacity-50"
              title="Summarize task"
            >
              <FileText className="w-4 h-4" />
            </button>
            
            <button
              onClick={onEdit}
              className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors duration-200"
              title="Edit task"
            >
              <Edit3 className="w-4 h-4" />
            </button>
            
            <button
              onClick={() => deleteTask(task.id)}
              className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors duration-200"
              title="Delete task"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {showSummary && summary && (
          <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-medium text-blue-900">AI Analysis</h4>
              <button
                onClick={() => setShowSummary(false)}
                className="text-blue-600 hover:text-blue-800"
              >
                ×
              </button>
            </div>
            <div className="text-sm text-blue-800 whitespace-pre-wrap">
              {summary}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};