import React, { useEffect } from 'react';
import { useTask } from '../contexts/TaskContext';

export const NotificationManager: React.FC = () => {
  const { tasks } = useTask();

  useEffect(() => {
    const checkDeadlines = () => {
      if ('Notification' in window && Notification.permission === 'granted') {
        const now = new Date();
        const tomorrow = new Date(now);
        tomorrow.setDate(tomorrow.getDate() + 1);

        tasks.forEach(task => {
          if (task.deadline && !task.completed) {
            const deadline = new Date(task.deadline);
            
            // Notify for tasks due tomorrow
            if (deadline.toDateString() === tomorrow.toDateString()) {
              new Notification('Task Due Tomorrow', {
                body: `"${task.title}" is due tomorrow`,
                icon: '/favicon.ico',
                tag: `task-${task.id}`,
              });
            }
            
            // Notify for overdue tasks
            if (deadline < now) {
              new Notification('Overdue Task', {
                body: `"${task.title}" is overdue`,
                icon: '/favicon.ico',
                tag: `overdue-${task.id}`,
              });
            }
          }
        });
      }
    };

    // Check deadlines every hour
    const interval = setInterval(checkDeadlines, 60 * 60 * 1000);
    
    // Initial check
    checkDeadlines();

    return () => clearInterval(interval);
  }, [tasks]);

  return null;
};