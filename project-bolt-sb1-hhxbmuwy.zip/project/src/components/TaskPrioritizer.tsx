import React, { useState } from 'react';
import { Zap, Brain, Calendar, AlertCircle } from 'lucide-react';
import { useTask } from '../contexts/TaskContext';
import { Task } from '../types';

export const TaskPrioritizer: React.FC = () => {
  const { tasks, prioritizeTasks, categories } = useTask();
  const [prioritizedTasks, setPrioritizedTasks] = useState<{ task: Task; reasoning: string }[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const handlePrioritize = async () => {
    setIsLoading(true);
    try {
      const result = await prioritizeTasks();
      setPrioritizedTasks(result);
    } catch (error) {
      console.error('Prioritization failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const incompleteTasks = tasks.filter(task => !task.completed);
  const getCategoryColor = (categoryName: string) => {
    const category = categories.find(cat => cat.name === categoryName);
    return category?.color || '#6b7280';
  };

  const priorityColors = {
    low: 'bg-green-100 text-green-800',
    medium: 'bg-yellow-100 text-yellow-800',
    high: 'bg-red-100 text-red-800',
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center">
            <Brain className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">AI Task Prioritizer</h2>
            <p className="text-gray-600">Get AI-powered task prioritization with reasoning</p>
          </div>
        </div>

        <button
          onClick={handlePrioritize}
          disabled={isLoading || incompleteTasks.length === 0}
          className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-6 py-2 rounded-lg font-medium transition-all duration-200 flex items-center space-x-2 disabled:opacity-50"
        >
          <Zap className="w-4 h-4" />
          <span>{isLoading ? 'Analyzing...' : 'Prioritize Tasks'}</span>
        </button>
      </div>

      {incompleteTasks.length === 0 ? (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Zap className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Active Tasks</h3>
          <p className="text-gray-600">Add some tasks to get AI-powered prioritization!</p>
        </div>
      ) : (
        <>
          {prioritizedTasks.length === 0 && !isLoading && (
            <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl p-6 text-center">
              <Brain className="w-12 h-12 text-purple-600 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-purple-900 mb-2">
                Ready for AI Analysis
              </h3>
              <p className="text-purple-700">
                Click "Prioritize Tasks" to get intelligent task ordering with detailed reasoning
              </p>
            </div>
          )}

          {isLoading && (
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600 mx-auto mb-4"></div>
              <p className="text-gray-600">AI is analyzing your tasks...</p>
            </div>
          )}

          {prioritizedTasks.length > 0 && (
            <div className="space-y-4">
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
                  <Brain className="w-5 h-5 text-purple-600" />
                  <span>AI-Prioritized Task List</span>
                </h3>
                
                <div className="space-y-4">
                  {prioritizedTasks.map((item, index) => (
                    <div
                      key={item.task.id}
                      className="border border-gray-200 rounded-lg p-4 hover:shadow-sm transition-shadow duration-200"
                    >
                      <div className="flex items-start space-x-4">
                        <div className="flex-shrink-0 w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center font-semibold">
                          {index + 1}
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-2 mb-2">
                            <h4 className="font-medium text-gray-900">{item.task.title}</h4>
                            
                            {item.task.category && (
                              <span
                                className="px-2 py-1 text-xs font-medium rounded-full text-white"
                                style={{ backgroundColor: getCategoryColor(item.task.category) }}
                              >
                                {item.task.category}
                              </span>
                            )}
                            
                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${priorityColors[item.task.priority]}`}>
                              {item.task.priority}
                            </span>
                          </div>

                          {item.task.deadline && (
                            <div className="flex items-center space-x-1 text-sm text-gray-500 mb-2">
                              <Calendar className="w-4 h-4" />
                              <span>Due: {new Date(item.task.deadline).toLocaleDateString()}</span>
                              {new Date(item.task.deadline) < new Date() && (
                                <span className="text-red-600 font-medium">(Overdue)</span>
                              )}
                            </div>
                          )}

                          <div className="bg-purple-50 rounded-lg p-3 mt-3">
                            <div className="flex items-start space-x-2">
                              <AlertCircle className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
                              <div>
                                <p className="text-sm font-medium text-purple-900 mb-1">AI Reasoning</p>
                                <p className="text-sm text-purple-700">{item.reasoning}</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};