import React, { useState } from 'react';
import { useTask } from '../contexts/TaskContext';
import { TaskCard } from './TaskCard';
import { TaskModal } from './TaskModal';
import { Task } from '../types';

export const TaskList: React.FC = () => {
  const { tasks } = useTask();
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [filter, setFilter] = useState<'all' | 'active' | 'completed'>('all');

  const filteredTasks = tasks.filter(task => {
    if (filter === 'active') return !task.completed;
    if (filter === 'completed') return task.completed;
    return true;
  });

  const completedCount = tasks.filter(task => task.completed).length;
  const totalCount = tasks.length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Your Tasks</h2>
          <p className="text-gray-600">
            {completedCount} of {totalCount} tasks completed
          </p>
        </div>

        <div className="flex space-x-2">
          {(['all', 'active', 'completed'] as const).map(filterType => (
            <button
              key={filterType}
              onClick={() => setFilter(filterType)}
              className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 capitalize ${
                filter === filterType
                  ? 'bg-blue-600 text-white'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
              }`}
            >
              {filterType} ({
                filterType === 'all' ? totalCount :
                filterType === 'active' ? totalCount - completedCount :
                completedCount
              })
            </button>
          ))}
        </div>
      </div>

      {filteredTasks.length === 0 ? (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <div className="w-8 h-8 border-2 border-dashed border-gray-400 rounded-full"></div>
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            {filter === 'all' ? 'No tasks yet' :
             filter === 'active' ? 'No active tasks' :
             'No completed tasks'}
          </h3>
          <p className="text-gray-600">
            {filter === 'all' ? 'Create your first task to get started!' :
             filter === 'active' ? 'All tasks are completed!' :
             'Complete some tasks to see them here.'}
          </p>
        </div>
      ) : (
        <div className="grid gap-4">
          {filteredTasks.map(task => (
            <TaskCard
              key={task.id}
              task={task}
              onEdit={() => setSelectedTask(task)}
            />
          ))}
        </div>
      )}

      {selectedTask && (
        <TaskModal
          task={selectedTask}
          onClose={() => setSelectedTask(null)}
        />
      )}
    </div>
  );
};